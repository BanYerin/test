package bankSystem;

import java.sql.*;
import java.io.*;
import java.util.Scanner;

//JDBC프로그래밍에 공통으로 사용되는 코드를 메소드로 작성한 클래스. DB연결, Connection객체 생성, Statement객체 생성, 객체 반납 기능에 대한 메소드를 가진 클래스
public class ConnectionSet {
	//Connection 인스턴스를 반환하는 메소드
	public static Connection getConnection() {
		//DB연결을 위한 설정
		String dbUrl = "jdbc:mysql://192.168.56.101:4567/bank_system";
		String dbUser = "xlvl98";
		String dbPw = "0520";
		Connection conn = null;
		
		try {
			//DB연결 작업
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(dbUrl, dbUser, dbPw);
		    System.out.println("DB연결완료");
		} catch(Exception e) {
			System.out.println(e);
		    System.out.println("DB Connection ERROR!!");
		} finally {
		    try {conn.close();} catch(Exception e){}
		}
		
		return conn;
	}
	
	//Connection객체 반납하는 메소드
	public static void close(Connection conn) {
		try {
			if(conn != null)
				conn.close();
		}catch(SQLException e) {
			e.printStackTrace();
			System.out.println("DB Connection close ERROR!");
		}
	}
	
	//Connection객체, Statement객체 반납하는 메소드
	public static void close(Connection conn, Statement stmt) {
		try {
			if(conn != null)
				conn.close();
			if(stmt != null)
				stmt.close();
		}catch(SQLException e) {
			e.printStackTrace();
			System.out.println("DB Connection&stmt close ERROR!");
		}
	}
	
	//Connection객체, Statement객체 반납하는 메소드
	public static void close(Connection conn, Statement stmt, ResultSet rs) {
		try {
			if(conn != null)
				conn.close();
			if(stmt != null)
				stmt.close();
			if(rs != null)
				rs.close();
		}catch(SQLException e) {
			e.printStackTrace();
			System.out.println("DB Connection & stmt & ResultSet close ERROR!");
		}
	}

}
